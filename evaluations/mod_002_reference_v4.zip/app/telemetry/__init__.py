"""Canonical telemetry domain modules."""
