"""Evidence-domain implementations."""
