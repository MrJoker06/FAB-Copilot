"""Knowledge-domain implementations."""
