"""Canonical manufacturing-domain implementations."""
